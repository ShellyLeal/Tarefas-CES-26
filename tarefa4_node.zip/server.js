var express        =         require("express");
var bodyParser     =         require("body-parser");
var app            =         express();
var cookieParser   =         require("cookie-parser");
var azure = require('azure-storage');


app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.get('/',function(req,res){
  res.sendfile("index.html");
});
app.get('/',function(req,res){
  console.log("Cookies: ",req.cookies);
});
app.post('/login',function(req,res){
  var user_name=req.body.user;
  var password=req.body.password;
  console.log("User name = "+user_name+", password is "+password);
  res.end("yes");
});
app.listen(3000,function(){
  console.log("Started on PORT 3000");
})

